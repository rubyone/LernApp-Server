'use strict'

var mongoose = require('mongoose')
var express = require('express')
var bodyParser = require('body-parser')
var app = express()
var port = process.env.PORT || 3030

var passport = require('./passport.js')
var User = require('./models/user.js')

// set up app
mongoose.connect(process.env.DBURL)
app.use(bodyParser.json())
app.use(passport.initialize())

// listen to routes
app.post('/user', function (req, res, next) {
  if (!req.body) return res.status(406).send('Not Acceptable')

  var username = req.body.username
  var password = req.body.password
  if (!username || !password) return res.status(406).send('username or password missing')

  User.findOne({ username: username }, function (err, user) {
    if (err) return next(err)
    if (user) return res.status(422).send('username already exists')

    var newUser = new User()
    newUser.username = username
    newUser.password = newUser.generateHash(password)

    newUser.save(function (err) {
      if (err) return next(err)
      newUser.password = undefined // dont expose password
      return res.json(newUser)
    })
  })
})

app.get('/user', function (req, res, next) {
  passport.authenticate('basic', { session: false }, function (err, user, info) {
    if (err) return next(err)
    if (!user) return res.status(403).send('authetication required')
    return res.json(user)
  })(req, res, next)
})

// launch
app.listen(port)
console.log('Server running on Port ' + port)

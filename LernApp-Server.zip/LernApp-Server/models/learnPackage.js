'use strict'

var mongoose = require('mongoose')

var learnPackageSchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true },
  description: { type: String, required: true },

  elements: { type: Array },
  owners: { type: Array },

  createdAt: { type: Date, 'default': Date.now },
  updatedAt: { type: Date, 'default': Date.now }
})

module.exports = mongoose.model('learnPackage', learnPackageSchema)

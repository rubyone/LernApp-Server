'use strict'

var passport = require('passport')
var BasicStrategy = require('passport-http').BasicStrategy
var User = require('./models/user.js')

passport.use(new BasicStrategy(
  function (username, password, done) {
    User.findOne({ username: username }, function (err, user) {
      if (err) return done(err)
      if (!user) return done(null, false)
      if (!user.validPassword(password)) return done(null, false)
      user.password = undefined // dont expose password
      return done(null, user)
    })
  }
))

module.exports = passport
